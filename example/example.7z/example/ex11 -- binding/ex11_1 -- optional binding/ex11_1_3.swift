let myNumber = Int(possibleNumber)

if let myNumber {
    print("My number is \(myNumber)")
}
// Prints "My number is 123"