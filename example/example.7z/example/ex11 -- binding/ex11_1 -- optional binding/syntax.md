# Swift
## Optional Binding
```
if let <#constantName#> = <#someOptional#> {
   <#statements#>
}
```