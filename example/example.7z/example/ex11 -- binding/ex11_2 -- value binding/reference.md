# reference
## guide reference
See [`Control Flow#Value-Binding` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow#Value-Bindings)