var surveyAnswer: String?
// surveyAnswer is automatically set to nil