let possibleNumber = "Hello World!!!"
let convertedNumber = Int(possibleNumber)

if convertedNumber != nil {
    print("\(convertedNumber) contains some integer value.")
}else{
    print("\(convertedNumber) does NOT contain any integer value.")
}
// Prints "Hello World!!! does NOT contain any integer value."