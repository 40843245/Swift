# Swift
## nil

> [!NOTE]
? In Objective-C, `nil` is a pointer to a nonexistent object. 
> 
> In Swift, `nil` isn’t a pointer — it’s the absence of a value of a certain type. Optionals of _any_ type can be set to `nil`, not just object types.