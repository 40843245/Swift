class Vehicle {
    final var currentSpeed = 0.0 // this property can not be overriden since it has modifier `final``.
    final var description: String { // this method can not be overriden since it has modifier `final``.
        return "traveling at \(currentSpeed) miles per hour"
    }
    func makeNoise() {
        // do nothing - an arbitrary vehicle doesn't necessarily make a noise
    }
}

class Train: Vehicle {
    override func makeNoise() {
        print("Choo Choo")
    }
}

class Car: Vehicle {
    var gear = 1
    override var description: String { // compiler error
        return super.description + " in gear \(gear)"
    }
}

class AutomaticCar: Car {
    override var currentSpeed: Double { // compiler error
        didSet {
            gear = Int(currentSpeed / 10.0) + 1
        }
    }
}