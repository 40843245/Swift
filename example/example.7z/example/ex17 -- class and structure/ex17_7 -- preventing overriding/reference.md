# reference
## guide reference
See [`Inheritance#Preventing-Overrides` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/inheritance#Preventing-Overrides)