/// example of [`Failable Initializers for Enumerations with Raw Values` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/initialization#Failable-Initializers-for-Enumerations-with-Raw-Values)
enum TemperatureUnit: Character {
    case kelvin = "K", celsius = "C", fahrenheit = "F"
}


let fahrenheitUnit = TemperatureUnit(rawValue: "F")
if fahrenheitUnit != nil {
    print("This is a defined temperature unit, so initialization succeeded.")
}else{
    print("This isn't a defined temperature unit, so initialization failed.")
}
// Prints "This is a defined temperature unit, so initialization succeeded."


let unknownUnit = TemperatureUnit(rawValue: "X")
if unknownUnit == nil {
    print("This isn't a defined temperature unit, so initialization failed.")
}else{
    print("This is a defined temperature unit, so initialization succeeded.") 
}
// Prints "This isn't a defined temperature unit, so initialization failed."