# NOTICE
> [!NOTE]
> You can’t define a failable and a nonfailable initializer with the same parameter types and names.

> [!NOTE]
> Strictly speaking, initializers don’t return a value. 
> 
> Rather, their role is to ensure that `self` is fully and correctly initialized by the time that initialization ends. 
>
> Although you write `return nil` to trigger an initialization failure, you don’t use the `return` keyword to indicate initialization success.

> [!NOTE]
> Checking for an empty string value (such as `""` rather than `"Giraffe"`) is **NOT** the same as checking for `nil` to indicate the absence of an _optional_ `String` value. 
> 
> In the example above, an empty string (`""`) is a valid, non-optional `String`. 
> 
> However, it’s not appropriate for an animal to have an empty string as the value of its `species` property. 
> 
> To model this restriction, the failable initializer triggers an initialization failure if an empty string is found.

> [!NOTE]
> A failable initializer can also delegate to a nonfailable initializer. 
> 
> Use this approach if you need to add a potential failure state to an existing initialization process that doesn’t otherwise fail.

> [!NOTE]
> You can delegate from `init?` to `init!` and vice versa
> 
> You can override `init?` with `init!` and vice versa. 
> 
> You can also delegate from `init` to `init!`, although doing so will trigger an assertion if the `init!` initializer causes initialization to fail.