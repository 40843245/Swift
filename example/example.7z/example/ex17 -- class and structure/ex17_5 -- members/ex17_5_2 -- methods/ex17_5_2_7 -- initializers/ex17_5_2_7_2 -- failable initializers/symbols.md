# Symbol
## failable initializer
### failable initializer that creats an optional instance -- (`init?`)
### failable initializer that creates an implicit unwrapped optional instance -- (`init!`)