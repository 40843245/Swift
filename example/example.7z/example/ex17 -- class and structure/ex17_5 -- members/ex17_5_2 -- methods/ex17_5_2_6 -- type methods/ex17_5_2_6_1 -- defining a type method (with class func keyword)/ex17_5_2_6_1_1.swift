class SomeClass {
    class func someTypeMethod() {
        // type method implementation goes here
    }
}