class SomeClass {
    class func someTypeMethod() {
        // type method implementation goes here
    }
}

// invoke it as static method in C.
SomeClass.someTypeMethod()