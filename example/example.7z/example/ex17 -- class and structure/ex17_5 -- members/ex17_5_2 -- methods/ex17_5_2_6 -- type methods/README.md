# NOTICE
> [!NOTE]
> In Objective-C, you can define type-level methods only for Objective-C classes. 
> 
> In Swift, you can define type-level methods for all classes, structures, and enumerations. 
> 
> Each type method is explicitly scoped to the type it supports.