struct CallableStruct {
    var value: Int
    func callAsFunction(_ number: Int, scale: Int) {
        print(scale * (number + value))
    }
}
let callable = CallableStruct(value: 100)

// These function call are equivalent.
callable(4, scale: 2)
callable.callAsFunction(4, scale: 2)
// Both function calls print 208.

