struct CallableStruct {
    var value: Int
    func callAsFunction(_ number: Int, scale: Int) {
        print(scale * (number + value))
    }
}
let callable = CallableStruct(value: 100)

// These function call are equivalent. However, we can not say these functions are identical, see (1) for more details.
callable(4, scale: 2)
callable.callAsFunction(4, scale: 2)
// Both function calls print 208.

// (1)
let someFunction1: (Int, Int) -> Void = callable(_:scale:)  // Error
let someFunction2: (Int, Int) -> Void = callable.callAsFunction(_:scale:)

