# NOTICE
> [!NOTE]
> If a property always takes the same initial value, provide a default value rather than setting a value within an initializer. 
> The end result is the same, but the default value ties the property’s initialization more closely to its declaration. 
> It makes for shorter, clearer initializers and enables you to infer the type of the property from its default value. 
> The default value also makes it easier for you to take advantage of default initializers and initializer inheritance, as described later in this chapter.