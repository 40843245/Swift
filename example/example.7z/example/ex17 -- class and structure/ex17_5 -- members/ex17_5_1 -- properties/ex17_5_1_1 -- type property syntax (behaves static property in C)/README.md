# NOTICE
> [!NOTE]
> The computed type property examples above are for read-only computed type properties, 
> 
> but you can also define read-write computed type properties with the same syntax as 
> 
> for computed instance properties.

# analogous to static property
> [!NOTE]
> Analogous to C, type properties behaves like a static property in C.