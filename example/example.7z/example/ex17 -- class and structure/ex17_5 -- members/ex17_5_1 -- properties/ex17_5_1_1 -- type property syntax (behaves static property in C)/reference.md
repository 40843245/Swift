# reference
## guide reference
See [`Properties` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties)