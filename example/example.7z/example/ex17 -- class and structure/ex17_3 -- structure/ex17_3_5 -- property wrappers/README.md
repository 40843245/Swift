# NOTICE
> [!NOTE]
> The declaration for `number` in the example above marks the variable as `private`,
>  
> which ensures `number` is used only in the implementation of `TwelveOrLess`. 
> 
> Code that’s written anywhere else accesses the value using the getter and setter for `wrappedValue`, and can’t use `number` directly. 
> 
> For information about `private`, see [Access Control](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/accesscontrol).