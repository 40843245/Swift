struct Resolution {
    var width = 0
    var height = 0
}