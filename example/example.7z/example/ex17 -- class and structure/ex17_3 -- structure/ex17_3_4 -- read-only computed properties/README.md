# NOTICE
> You must declare computed properties — including read-only computed properties — as variable properties with the `var` keyword, 
> 
> because their value isn’t fixed. 
> 
> The `let` keyword is only used for constant properties,
>  
> to indicate that their values can’t be changed once they’re set as part of instance initialization.