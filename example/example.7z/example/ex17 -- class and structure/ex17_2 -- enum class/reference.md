# reference
## guide reference
See [`Enum class` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations)