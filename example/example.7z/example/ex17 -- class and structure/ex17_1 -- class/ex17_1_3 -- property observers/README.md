# NOTICE
> [!NOTE]
> The `willSet` and `didSet` observers of superclass properties are called 
> 
> when a property is set in a subclass initializer, 
> 
> after the superclass initializer has been called. 
> 
> They aren’t called while a class is setting its own properties, 
> 
> before the superclass initializer has been called.
> 
> For more information about initializer delegation, see [Initializer Delegation for Value Types](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/initialization#Initializer-Delegation-for-Value-Types) and [Initializer Delegation for Class Types](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/initialization#Initializer-Delegation-for-Class-Types).

> [!NOTE]
> If you pass a property that has observers to a function as an in-out parameter, 
> 
> the `willSet` and `didSet` observers are always called. 
> 
> This is because of the copy-in copy-out memory model for in-out parameters: 
> 
> The value is always written back to the property at the end of the function. 
> 
> For a detailed discussion of the behavior of in-out parameters, see [In-Out Parameters](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/declarations#In-Out-Parameters).