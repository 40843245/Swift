# NOTICE
> [!NOTE]
> In class, if a property marked with the `lazy` modifier is accessed by multiple threads simultaneously and the property hasn’t yet been initialized. 
> 
> There’s no guarantee that the property will be initialized only once.