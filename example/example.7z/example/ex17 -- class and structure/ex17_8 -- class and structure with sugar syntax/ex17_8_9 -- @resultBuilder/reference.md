# reference
## guide reference
See [`result builders` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/advancedoperators/#Result-Builders)

See [`@resultBuilder` (official website)](See [`resultBuilder` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/advancedoperators/#Result-Builders))