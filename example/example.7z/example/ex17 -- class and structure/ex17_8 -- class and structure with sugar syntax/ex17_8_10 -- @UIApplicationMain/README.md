# Deprecated

> This attribute is deprecated; 
>
> use the [main](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/attributes#main) attribute instead.
>
> In Swift 6, using this attribute will be an error.