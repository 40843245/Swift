@main
struct MyTopLevel {
    static func main() {
        // Top-level code goes here
    }
}