# reference
## guide reference
See [`main` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/attributes/#main)