/// example that illustrate the other way to define a static main function (i.e. the entry point) by conforming a protocol 
/// shown as follows.
protocol MyTopLevel {
    static func main() throws
}