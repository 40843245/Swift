/// example of use of `@objcMembers`
/// `@objcMembers` is an annotation (uses sugar syntax) to tell the compiler the followed class etc.
/// to enforce all members are accepted in Objective-C.  

/// Enforce the all members of class Counter is accepted in Objective-C.
@objcMembers class Counter {
    // it is considered to be annotated with `@objMembers`
    var count = 0
    // it is considered to be annotated with `@objMembers`
    func increment() {
        if let amount = dataSource?.increment?(forCount: count) {
            count += amount
        } else if let amount = 1 {
            count += amount
        }
    }
}

var counter = Counter()