/// example of use of `@objc`
/// `@objc` is an annotation (uses sugar syntax) to tell the compiler the followed identifier, class, protocol etc.
/// to enforce it is accepted in Objective-C.  

class ExampleClass: NSObject {
    @objc var enabled: Bool {
        @objc(isEnabled) get {
            // Return the appropriate value
        }
    }
}