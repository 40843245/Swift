/// example that illustrate the fact that 
/// dynamic member lookup by key path can be used to implement a wrapper type in a way that supports compile-time type checking.

struct Point { var x, y: Int }


@dynamicMemberLookup
struct PassthroughWrapper<Value> {
    var value: Value
    subscript<T>(dynamicMember member: KeyPath<Value, T>) -> T {
        get { return value[keyPath: member] }
    }
}


let point = Point(x: 381, y: 431)
let wrapper = PassthroughWrapper(value: point)
print(wrapper.x)