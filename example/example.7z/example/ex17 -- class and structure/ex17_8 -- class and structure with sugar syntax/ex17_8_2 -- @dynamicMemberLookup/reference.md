# reference
## guide reference
See [`dynamicMemberLookup` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/attributes/#dynamicMemberLookup)