/// example of use of `@objc`
/// `@objc` is an annotation (uses sugar syntax) to tell the compiler the followed identifier, class, protocol etc.
/// to enforce it is NOT accepted in Objective-C.   

/// Enforce the protocol CounterDataSource is NOT accepted in Objective-C.
@nonobjc protocol CounterDataSource {
    /// Enforce the method increment is NOT accepted in Objective-C.
    @nonobjc optional func increment(forCount count: Int) -> Int
    /// Enforce the property fixedIncrement is NOT accepted in Objective-C.
    @nonobjc optional var fixedIncrement: Int { get }
}