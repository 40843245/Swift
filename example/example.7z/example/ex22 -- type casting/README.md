# NOTICE
> [!NOTE]
> Casting doesn’t actually modify the instance or change its values. 
> 
> The underlying instance remains the same; it’s simply treated and accessed as an instance of the type to which it has been cast.

> [!NOTE]
> The `Any` type represents values of any type, including optional types. 
> 
> Swift gives you a warning if you use an optional value where a value of type `Any` is expected. 
> 
> If you really do need to use an optional value as an `Any` value, you can use the `as` operator to explicitly cast the optional to `Any`, as shown below.
>
> ```
> let optionalNumber: Int? = 3
> things.append(optionalNumber)        // Warning
> things.append(optionalNumber as Any) // No warning
> ```