# reference
## guide reference
See [`Control Flow#Switch`](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow#Switch)1