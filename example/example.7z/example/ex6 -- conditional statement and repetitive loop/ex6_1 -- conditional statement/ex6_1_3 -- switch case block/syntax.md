# Swift
## syntax
### switch case block
With RE (regular expression), it can be written as 

```
<switchCaseBlock> :=
switch <expression> {
    case <matchedCase> (,<matchedCase>)* :
        <matchedCaseStatements>
    default:
        <defaultStatements>
    }
```

where 

```
<defaultStatements> := <statements>
<defaultStatements> := <statements>
<staments> := (<statement>)+
```

and 

`<statement>` refer one statement in `Swift`.

> [!TIP]
> Recall that 
> 
> `a*` means zero, one or more elements to repeat `a`.
> 
> `a+` means one or more elements to repeat `a`.


For more details, see [`Control Flow#Switch`](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow#Switch)