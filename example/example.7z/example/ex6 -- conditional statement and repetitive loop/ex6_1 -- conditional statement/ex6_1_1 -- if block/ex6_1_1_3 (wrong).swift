let i = 1
if i {
    // this example will not compile, and will report an error
}