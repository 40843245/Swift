let i = 1
if i == 1 {
    // this example will compile successfully
}