# Swift
## syntax
### guard else block
```
guard <expression> else {
    <statements>
    <exitStatment>
}
```

where 

`<exitStatment>` indicates it should exits the guard scope and it should start one of these following keywords

+ `continue`
+ `break`
+ `return`
+ `throw`

Otherwise, we will get an error

```
'guard' body must not fall through, consider using a 'continue' or 'return' to exit the scope
```

When `<expression>` is evaluated to `false`, it will jump to guard scope.

For more details, see [`Swift guard Statement` (Programiz)](https://www.programiz.com/swift-programming/guard-statement)
