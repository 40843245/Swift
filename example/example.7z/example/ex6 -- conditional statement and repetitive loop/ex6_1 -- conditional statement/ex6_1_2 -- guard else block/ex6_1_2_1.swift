func checkOddEven() {
  var number = 23

  guard number % 2 == 0 else {    
    print("Odd Number")
    return
  }

  print("Even Number")
}

checkOddEven()