# reference
## guide reference
See [`Swift guard Statement` (Programiz)](https://www.programiz.com/swift-programming/guard-statement)