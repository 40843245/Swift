let upperbound = 10
let step = 2
var index = 1

while index <= upperbound {
    print("\(index)\n")
    index += step
}

print("\(index)\n")
