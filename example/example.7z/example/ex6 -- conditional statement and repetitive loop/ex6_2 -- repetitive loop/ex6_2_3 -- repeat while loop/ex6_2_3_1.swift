let upperbound = 10
let step = 2
var index = 1

repeat {
    print("\(index)\n")
    index += step
} while index <= upperbound  

print("\(index)\n")
