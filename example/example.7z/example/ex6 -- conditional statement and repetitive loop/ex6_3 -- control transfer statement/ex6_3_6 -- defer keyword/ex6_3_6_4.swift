var score = 1
while score <= 20 {
    defer {
        print(score)
    }
    print("current score:\(score)")
    score += 5
}

print(score)

/*
current score:1
6
current score:6
11
current score:11
16
current score:16
21
21
*/