var score = 1
if score < 10 {
    defer {
        print(score)
    }
    score += 5
}
// Prints "6"