# reference
## guide reference
See [`Control Flow#Break` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow#Break)