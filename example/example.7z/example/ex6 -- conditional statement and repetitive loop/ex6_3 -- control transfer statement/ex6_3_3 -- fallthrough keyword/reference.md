# reference
## guide reference
See [`Control Flow#Fallthrough` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow#Fallthrough)