# reference
## guide reference
See [`Control Flow#Continue` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow#Continue)