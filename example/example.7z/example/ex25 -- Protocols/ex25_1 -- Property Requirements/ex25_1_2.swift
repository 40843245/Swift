protocol AnotherProtocol {
    static var someTypeProperty: Int { get set }
}