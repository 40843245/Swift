# NOTICE
> [!NOTE]
> If a conforming type satisfies the requirements for multiple constrained extensions that provide implementations for the same method or property, 
>
> Swift uses the implementation corresponding to the most specialized constraints.