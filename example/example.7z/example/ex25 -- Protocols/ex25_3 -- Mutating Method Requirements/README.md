# NOTICE
> [!NOTE]
> If you mark a protocol instance method requirement as `mutating`,
> 
> you don’t need to write the `mutating` keyword when writing an implementation of that method for a class. 
> 
> The `mutating` keyword is only used by structures and enumerations.