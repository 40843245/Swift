# NOTICE
> [!NOTE]
> Existing instances of a type automatically adopt and conform to a protocol when 
> 
> that conformance is added to the instance’s type in an extension.