// define a protocol named `HasArea`
protocol HasArea {
    var area: Double { get }
}

// correctly conforms to HasArea protocol
class Circle: HasArea {
    let pi = 3.1415927
    var radius: Double
    var area: Double { return pi * radius * radius }
    init(radius: Double) { self.radius = radius }
}

// correctly conforms to HasArea protocol
class Country: HasArea {
    var area: Double
    init(area: Double) { self.area = area }
}

// NOT correctly conform to HasArea protocol
class Animal {
    var legs: Int
    init(legs: Int) { self.legs = legs }
}

let objects: [AnyObject] = [
    Circle(radius: 2.0),
    Country(area: 243_610),
    Animal(legs: 4)
]

for object in objects {
    // check `object` variable conforms to HasArea protocol.
    if let objectWithArea = object as? HasArea { // if conforms
        print("Area is \(objectWithArea.area)")
    } else { // NOT conform
        print("Something that doesn't have an area")
    }
}
// Area is 12.5663708
// Area is 243610.0
// Something that doesn't have an area