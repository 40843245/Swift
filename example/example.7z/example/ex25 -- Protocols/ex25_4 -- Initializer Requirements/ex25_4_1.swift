protocol SomeProtocol {
    init(someParameter: Int)
}