# NOTICE
> [!NOTE]
> Types don’t automatically adopt a protocol just by satisfying its requirements. 
> 
> They must always explicitly declare their adoption of the protocol.