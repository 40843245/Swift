extension PrettyTextRepresentable  {
    var prettyTextualDescription: String {
        return textualDescription
    }
}