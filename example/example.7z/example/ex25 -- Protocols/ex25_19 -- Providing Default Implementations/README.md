# NOTICE
> [!NOTE]
> Protocol requirements with default implementations provided by extensions are distinct from optional protocol requirements. 
> 
> Although conforming types don’t have to provide their own implementation of either, 
> 
> requirements with default implementations can be called without optional chaining.