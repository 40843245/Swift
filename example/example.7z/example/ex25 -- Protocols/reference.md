# reference
## guide reference
See [`Protocols` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/protocols/)