protocol InheritingProtocol: SomeProtocol, AnotherProtocol {
    // protocol definition goes here
}