# NOTICE
> [!NOTE]
> You don’t need to mark protocol initializer implementations with the `required` modifier on classes that are marked with the `final` modifier, 
> 
> because final classes can’t subclassed. For more about the `final` modifier. 
> 
> See [Preventing Overrides](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/inheritance#Preventing-Overrides).