# NOTICE
> [!NOTE]
> Strictly speaking, you can write a custom class that conforms to `CounterDataSource` without implementing _either_ protocol requirement. 
>
> They’re both optional, after all. 
> 
> Although technically allowed, this wouldn’t make for a very good data source.