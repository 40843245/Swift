# NOTICE
> [!NOTE]
> Because protocols are types, begin their names with a capital letter 
> 
> (such as `FullyNamed` and `RandomNumberGenerator`) to match the names of other types in Swift 
> 
> (such as `Int`, `String`, and `Double`).