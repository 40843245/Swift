# reference
## guide reference
See [`Optional Chaining` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/optionalchaining)