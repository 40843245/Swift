# NOTICE
> [!NOTE]
> If the code to download a photo could throw an error,
> 
> you would call `withThrowingTaskGroup(of:returning:body:)` instead.