let http404Error = (404, "Not Found")
// http404Error is of type (Int, String), and equals (404, "Not Found")

print("The status code is \(http404Error.0)")
// Prints "The status code is 404"
print("The status message is \(http404Error.1)")
// Prints "The status message is Not Found"