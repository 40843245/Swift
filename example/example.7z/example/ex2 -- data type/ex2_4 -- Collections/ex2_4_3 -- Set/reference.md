# reference
## guide reference

Aee [`Collection Types` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/collectiontypes/)