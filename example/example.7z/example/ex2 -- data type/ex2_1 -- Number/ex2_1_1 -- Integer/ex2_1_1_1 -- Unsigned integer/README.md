# Swift
## Unsigned Integer

- On a 32-bit platform, `UInt` is the same size as `UInt32`.   
- On a 64-bit platform, `UInt` is the same size as `UInt64`.