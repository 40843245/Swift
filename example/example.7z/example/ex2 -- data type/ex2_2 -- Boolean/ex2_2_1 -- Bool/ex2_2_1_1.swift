let tf1: Bool = true
let tf2: Bool = false
