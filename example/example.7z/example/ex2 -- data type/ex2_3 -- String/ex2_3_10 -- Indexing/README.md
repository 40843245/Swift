# NOTICE
> [!NOTE]
> You can use the `startIndex` and `endIndex` properties and the `index(before:)`, `index(after:)`, and `index(_:offsetBy:)` methods on any type
>
> that conforms to the `Collection` protocol. 
>
> This includes `String`, as shown here, as well as collection types such as `Array`, `Dictionary`, and `Set`.