# NOTICE
> [!NOTE]
> You can use the `insert(_:at:)`, `insert(contentsOf:at:)`, `remove(at:)`, and `removeSubrange(_:)` methods on any type that conforms to the `RangeReplaceableCollection` protocol. 
>
> This includes `String`, as shown here, as well as collection types such as `Array`, `Dictionary`, and `Set`.