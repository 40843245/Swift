# NOTICE
> [!NOTE]
> The expressions you write inside parentheses within an interpolated string can’t contain an unescaped backslash (`\`), a carriage return, or a line feed. 
> 
> However, they can contain other string literals.