var emptyString = ""               // empty string literal
var anotherEmptyString = String()  // initializer syntax
// these two strings are both empty, and are equivalent to each other

if emptyString.isEmpty {
    print("Nothing to see here")
}else{
    print("It is not empty")
}
// Prints "Nothing to see here"

if anotherEmptyString.isEmpty {
    print("Nothing to see here")
}else{
    print("It is not empty")
}
// Prints "Nothing to see here"

if emptyString == anotherEmptyString {
    print("emptyString and anotherEmptyString are same")
} else {
    print("emptyString and anotherEmptyString are NOT same")
}
// Prints "emptyString and anotherEmptyString are same"

if emptyString === anotherEmptyString {
    print("emptyString and anotherEmptyString are same")
} else {
    print("emptyString and anotherEmptyString are NOT same")
}
// compiler error: argument type 'String' expected to be an instance of a class or class-constrained type
