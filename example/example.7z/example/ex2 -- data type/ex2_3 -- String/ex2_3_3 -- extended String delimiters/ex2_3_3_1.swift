let threeMoreDoubleQuotationMarks = #"""
Here are three more double quotes: """
"""#