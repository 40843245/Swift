# NOTICE
> [!NOTE]
> You can’t append a `String` or `Character` to an existing `Character` variable, 
> 
> because a `Character` value must contain a single character only.