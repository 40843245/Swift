class SomeClass {
    var someProperty = 42
}
let c = SomeClass()
let y = c.someProperty  // Member access

var t = (10, 20, 30)
t.0 = t.1
// Now t is (20, 20, 30)