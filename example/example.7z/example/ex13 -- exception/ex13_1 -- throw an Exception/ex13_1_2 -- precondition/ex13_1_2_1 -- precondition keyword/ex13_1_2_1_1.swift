let index  = -2
precondition(index > 0, "Index must be greater than zero.")