# reference
## guide reference
See start from this section [`Basic of Swift#Assertions and Preconditions` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics#Assertions-and-Preconditions) to the end of this article.

Also see [`Error Handling (official website)`](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/errorhandling/) for greater details.

Also see [`Declaration#Rethrowing Functions and Methods` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/declarations/#Rethrowing-Functions-and-Methods)