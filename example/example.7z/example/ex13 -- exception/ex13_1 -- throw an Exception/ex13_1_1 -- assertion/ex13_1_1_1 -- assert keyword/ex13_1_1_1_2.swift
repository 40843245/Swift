let age = -3
assert(age >= 0)
// This assertion fails because -3 isn't >= 0.