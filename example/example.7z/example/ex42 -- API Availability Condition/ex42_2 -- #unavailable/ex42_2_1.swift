func isIosElevenDotZeroVersion() -> Bool{
    if #unavailable(iOS 11.0, *) {
        // return false only when the running platform is unavailable on IOS 11.0 version.
        return false
    } else {
        // return true otherwise.
        return true
    }
}

Bool isIosElevenDotZeroVersionFlag = isIosElevenDotZeroVersion();
print(isIosElevenDotZeroVersionFlag)