func isIosElevenDotZeroVersion() -> Bool{
    if #available(iOS 11.0, *) {
        // return true only when the running platform is available on IOS 11.0 version.
        return true
    } else {
        // return false otherwise.
        return false
    }
}

Bool isIosElevenDotZeroVersionFlag = isIosElevenDotZeroVersion();
print(isIosElevenDotZeroVersionFlag)