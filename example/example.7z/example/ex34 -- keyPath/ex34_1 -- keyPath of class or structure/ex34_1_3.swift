class SomeClass: NSObject {
    @objc var someProperty: Int
    init(someProperty: Int) {
       self.someProperty = someProperty
    }
}


let c = SomeClass(someProperty: 12)
let keyPath = #keyPath(SomeClass.someProperty)


if let value = c.value(forKey: keyPath) {
    print(value)
}
// Prints "12"

extension SomeClass {
    func getSomeKeyPath() -> String {
        return #keyPath(someProperty)
    }
}
print(keyPath == c.getSomeKeyPath())
// Prints "true"