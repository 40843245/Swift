# reference
## guide reference
See [`Basic of Swift#Tuples` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics#Tuples)