# NOTICE
> [!NOTE]
> Extensions can add new functionality to a type, but they can’t override existing functionality.

> [!NOTE]
> If you define an extension to add new functionality to an existing type, 
> 
> the new functionality will be available on all existing instances of that type, 
> 
> even if they were created before the extension was defined.

> [!NOTE]
> Extensions can add new computed properties, 
> 
> but they can’t add stored properties, 
> 
> or add property observers to existing properties.

> [!NOTE]
> If you provide a new initializer with an extension, 
> 
> you are still responsible for making sure that each instance is fully initialized once the initializer completes.

> [!NOTE]
> `number.kind` is already known to be of type `Int.Kind`. 
> 
> Because of this, all of the `Int.Kind` case values can be written in shorthand form inside the `switch` statement, 
> 
> such as `.negative` rather than `Int.Kind.negative`.