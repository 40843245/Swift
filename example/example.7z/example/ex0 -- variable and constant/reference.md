# reference
## guide reference
See [`Learning Dart as a Swift developer#Variable`](https://dart.dev/resources/coming-from/swift-to-dart#variables)

Also see [`Basic of Swift#Constants-and-Variables` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/#Constants-and-Variables) for more details.