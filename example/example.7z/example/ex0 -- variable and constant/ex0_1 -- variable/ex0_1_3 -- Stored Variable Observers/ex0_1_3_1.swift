let height = 1.5
let weight = 75.0

var bmi: Double = weight/(height * height) {
   
    /// Define the willSet observer, a willSet observer is called just before the value of the variable or property is set.
   willSet(newValue) {
        self = newValue
   }


    /// Define the didSet observer, a didSet observer is called immediately after the new value is set.
   didSet(newValue) {
      self = newValue
   }
}