# reference
## guide reference
See [`Stored Variable Observers and Property Observers` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/declarations#Stored-Variable-Observers-and-Property-Observers)