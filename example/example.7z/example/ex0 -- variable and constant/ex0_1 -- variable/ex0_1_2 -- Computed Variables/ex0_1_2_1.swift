let height = 1.5
let weight = 75.0

var bmi: Double = {
    get{
        return weight/(height * height) 
    }
    set(newValue){
        self = newValue
    }
}