// To declare multiple constants or multiple variables on a single line, separated by commas.
var x = 0.0, y = 0.0, z = 0.0