// To define multiple related variables of the same type on a single line, 
// separated by commas, with a single type annotation after the final variable name.
var red, green, blue: Double