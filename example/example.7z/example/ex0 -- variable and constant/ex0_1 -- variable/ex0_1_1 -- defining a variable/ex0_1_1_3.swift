var welcomeMessage: String
welcomeMessage = "Hello"