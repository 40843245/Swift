# NOTICE
> [!NOTE]
> You can override a failable initializer with a nonfailable initializer but not the other way around.
