# NOTICE
> [!NOTE]
> You can’t add property observers to inherited constant stored properties or inherited read-only computed properties. 
> 
> The value of these properties can’t be set, 
> 
> and so it isn’t appropriate to provide a `willSet` or `didSet` implementation as part of an override.
> 
> Note also that you can’t provide both an overriding setter and an overriding property observer for the same property. 
> 
> If you want to observe changes to a property’s value, and you are already providing a custom setter for that property, 
> 
> then you can simply observe any value changes from within the custom setter.