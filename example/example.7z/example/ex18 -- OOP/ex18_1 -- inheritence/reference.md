# reference
## guide reference
See [`Inheritence` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/inheritance)