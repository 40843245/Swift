# NOTICE
> [!NOTE]
> Subclasses can modify inherited variable properties during initialization, 
> 
> but can’t modify inherited constant properties.