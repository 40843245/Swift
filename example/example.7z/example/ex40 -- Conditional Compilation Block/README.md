# NOTICE
> [!NOTE]
> Each statement in the body of a conditional compilation block is parsed even if it’s not compiled. 
> 
> However, there’s an exception if the compilation condition includes a `swift()` or `compiler()` platform condition: 
> 
> The statements are parsed only if the language or compiler version matches what is specified in the platform condition.
> 
> This exception ensures that an older compiler doesn’t attempt to parse syntax introduced in a newer version of Swift.