func log(
    _ expression1: @autoclosure () -> Any,
    _ expression2: @autoclosure () -> Any,
    _ expression3: @autoclosure () -> Any,
) {
    #if DEBUG
        print(expression1())
    #elseif swift(>=4.2)
        print(expression2())
    #else 
        print(expression2())        
    #endif
}