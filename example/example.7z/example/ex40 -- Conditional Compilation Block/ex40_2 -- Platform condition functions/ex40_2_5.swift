func canImportFirebaseAppModule(
    _ expression1: @autoclosure () -> Any,
    _ expression2: @autoclosure () -> Any,
){
    #if canImport(FirebaseApp)
        print(expression1())
    #else
        print(expression2())
    #endif
}
