func isOnArm64(
    _ expression1: @autoclosure () -> Any,
    _ expression2: @autoclosure () -> Any,
){
    #if arch(arm64)
        print(expression1())
    #else
        print(expression2())
    #endif
}
