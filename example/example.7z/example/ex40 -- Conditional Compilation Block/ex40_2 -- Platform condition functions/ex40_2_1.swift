func isOnMacOs(
    _ expression1: @autoclosure () -> Any,
    _ expression2: @autoclosure () -> Any,
){
    #if os(macOS)
        print(expression1())
    #else
        print(expression2())
    #endif
}
