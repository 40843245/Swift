# reference
## guide reference
See [`Conditional Compilation Block` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/statements#Conditional-Compilation-Block)