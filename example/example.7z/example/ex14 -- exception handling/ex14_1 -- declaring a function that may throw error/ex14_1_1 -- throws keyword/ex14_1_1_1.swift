func canThrowAnError() throws {
    // this function may or may not throw an error
}