func someThrowingFunction() throws{
    throw "Error!!!"
}

func anotherThrowingFunction() throws{
    throw "Another Error!!!"
}

var sum = Void -> Void
sum = try someThrowingFunction()

sum = try? someThrowingFunction()

sum = try! someThrowingFunction()

