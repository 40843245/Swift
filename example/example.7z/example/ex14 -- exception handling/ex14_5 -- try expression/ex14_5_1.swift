func someThrowingFunction() throws{
    throw "Error!!!"
}

func anotherThrowingFunction() throws{
    throw "Another Error!!!"
}

var sum = Void -> Void

// try applies to both function calls
sum = try someThrowingFunction() + anotherThrowingFunction()

// try applies to both function calls
sum = try (someThrowingFunction() + anotherThrowingFunction())

// Error: try applies only to the first function call
sum = (try someThrowingFunction()) + anotherThrowingFunction()