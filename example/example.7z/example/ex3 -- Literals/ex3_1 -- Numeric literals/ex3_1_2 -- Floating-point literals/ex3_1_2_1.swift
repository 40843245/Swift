let decimalDouble = 12.1875    // 12.1875
let exponentDouble = 1.21875e1 // 12.1875
let hexadecimalDouble = 0xC.3p0 // 12.1875