# reference
## guide reference
See [`Basic of Swift#Numeric Literals` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics#Numeric-Literals)