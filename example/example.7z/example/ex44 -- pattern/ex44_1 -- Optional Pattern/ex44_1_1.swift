let someOptional: Int? = 42
// Match using an enumeration case pattern.
if case .some(let x) = someOptional {
    print(x)
}


// Match using an optional pattern.
if case let x? = someOptional {
    print(x)
}