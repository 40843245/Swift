class SomeClass: NSObject {
    @objc let property: String


    @objc(doSomethingWithInt:)
    func doSomething(_ x: Int) { }


    init(property: String) {
        self.property = property
    }
}
let selectorForMethod = #selector(SomeClass.doSomething(_:))
let selectorForPropertyGetter = #selector(getter: SomeClass.property)