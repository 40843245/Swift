func oneMore(than number: Int) -> Int {
    return number + 1
}

var myNumber = 1

// read access happen at execution of start of invocation of `oneMore` fumction.
// write access happen at execution of assignment to `myNumber`.
myNumber = oneMore(than: myNumber)
print(myNumber)
// Prints "2"