# NOTICE
> [!NOTE]
> Because operators are functions, they can also have long-term accesses to their in-out parameters.
>
> For example, if `balance(_:_:)` was an operator function named `<^>`, writing `playerOneScore <^> playerOneScore` would result in the same conflict as `balance(&playerOneScore, &playerOneScore)`.