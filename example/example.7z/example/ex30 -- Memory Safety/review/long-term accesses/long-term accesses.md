# long-term accesses
## intro
