# conflicting access
## intro
According in [`Understanding Conflicting Access to Memory` (official website of `Swift`)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/memorysafety#Understanding-Conflicting-Access-to-Memory)

```
A conflicting access to memory can occur when different parts of your code are trying to access the same location in memory at the same time. Multiple accesses to a location in memory at the same time can produce unpredictable or inconsistent behavior. In Swift, there are ways to modify a value that span several lines of code, making it possible to attempt to access a value in the middle of its own modification.
```

For more understanding, using visual way by taking a glance at `conflict access example1.png`.