# NOTICE
> [!NOTE]
> conflicting access discussed here can happen on multiple thread.
> 
> However, in Swift, it also can happen a single thread and doesn’t involve concurrent or multithreaded code. 
> 
> In other programming lanugage, it may not happen.
