# conflicting access example
Take an example of official docs -- [`Memory Safety#Understanding Conflicting Access to Memory` (official docs)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/memorysafety#Understanding-Conflicting-Access-to-Memory) and its description.

You can see a similar problem by thinking about how you update a budget that’s written on a piece of paper. 

Updating the budget is a two-step process: 

1. First you add the items’ names and prices, and then you change the total amount to reflect the items currently on the list. 

Before and after the update, you can read any information from the budget and get a result, as shown in the figure `use case of conflicting access example1.png`

2. While you’re adding items to the budget, it’s in a temporary, invalid state 
because the total amount hasn’t been updated to reflect the newly added items. 
Reading the total amount during the process of adding an item gives you incorrect information.

This example (shown in `use case of conflicting access example1.png`) also demonstrates a challenge you may encounter when fixing conflicting access to memory: 

+ There are sometimes multiple ways to fix the conflict that produce different answers, and it’s not always obvious which answer is correct. 

In this example, depending on whether you wanted the original total amount or the updated total amount, either $5 or $320 could be the result (which due to conflicting access to memory access)  

Before you can fix the conflicting access, you have to determine what it was intended to do.
