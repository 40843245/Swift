# characteristics of memory access
According to [`Characteristics of Memory Access` (official website in `Swift`)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/memorysafety#Understanding-Conflicting-Access-to-Memory)

There are three characteristics of memory access to consider in the context of conflicting access:

1. whether the access is a read or a write 
2. the duration of the access, and 
3. the location in memory being accessed. Specifically, a conflict occurs if you have two accesses that meet all of the following conditions:

- The accesses aren’t both reads, and aren’t both atomic.
    
- They access the same location in memory.
    
- Their durations overlap. (What is duration overlap, see `duration overlaps example1.png` as example.)

The difference between a read and write access is usually obvious: 

+ a write access changes the location in memory, 

but a read access doesn’t. The location in memory refers to what is being accessed — 

for example, a variable, constant, or property. 

The duration of a memory access is either instantaneous or long-term.

An access is _atomic_ if it’s a call to an atomic operation on [`Atomic`](https://developer.apple.com/documentation/synchronization/atomic) or [`AtomicLazyReference`](https://developer.apple.com/documentation/synchronization/atomiclazyreference), 

or it it uses only C atomic operations; otherwise it’s nonatomic. For a list of C atomic functions, see the [`stdatomic(3)` man page](https://github.com/apple/darwin-libplatform/blob/main/man/stdatomic.3).

## figure illustrating happen of conflicting access
The happen of conflicting access, see an example `use case of conflicting access example1.png`.

In this example, a process named `process1` writes value to variable `a`. 

During writing value to variable `a`, an another process named `process2` reads the value of variable `a`.

The above situation satisfies three above conditions of conflicting access.

- The accesses aren’t both reads, and aren’t both atomic.
    
- They access the same location in memory.
    
- Their durations overlap. 

Thus, a conflicting access may occur.