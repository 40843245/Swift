# prove that never conflicting access

Stated in last paragraph of [`Memory Safety` (official docs)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/memorysafety#Understanding-Conflicting-Access-to-Memory)

Specifically, it can prove that overlapping access to properties of a structure is safe if the following conditions apply:

- You’re accessing only stored properties of an instance, not computed properties or class properties.
    
- The structure is the value of a local variable, not a global variable.
    
- The structure is either not captured by any closures, or it’s captured only by nonescaping closures.
    
If the compiler can’t prove the access is safe, it doesn’t allow the access.