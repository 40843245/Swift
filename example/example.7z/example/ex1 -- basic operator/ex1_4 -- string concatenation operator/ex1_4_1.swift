let string1 = "hello, " + "world"  // equals "hello, world"
