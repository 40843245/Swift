let range1 = ...5
range1.contains(7)   // false
range1.contains(4)   // true
range1.contains(-1)  // true