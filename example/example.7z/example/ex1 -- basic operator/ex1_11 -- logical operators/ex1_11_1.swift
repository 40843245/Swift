func printLogicalOperationResult(tf1 : Bool, tf2: Bool){
    print("-------------------------------------")
    print(tf1)
    print(tf2)
    print("!\(tf1) : \(!tf1)")
    print("\(tf1) || \(tf2) : \(tf1 || tf2)")
    print("\(tf1) && \(tf2) : \(tf1 && tf2)")
    print("-------------------------------------")
}

Bool tf1 = true
Bool tf2 = false

printLogicalOperationResult(tf1,tf1)

printLogicalOperationResult(tf2,tf1)

printLogicalOperationResult(tf1,tf2)

printLogicalOperationResult(tf2,tf2)