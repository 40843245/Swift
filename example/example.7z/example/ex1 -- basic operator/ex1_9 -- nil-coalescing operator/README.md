# NOTICE
> [!NOTE]
> If the value of `a` is non-`nil`, the value of `b` isn’t evaluated.
> 
> This is known as _short-circuit evaluation_.