# nil-coalescing operator
## equivalence
`a ?? b` is equivalent to `a != nil ? a! : b`