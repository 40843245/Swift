func getDefaultColorName(){
    print("getDefaultColorName function was called.")
    return "red"
}
var userDefinedColorName: String?   // defaults to nil

var colorNameToUse = userDefinedColorName ?? getDefaultColorName() // userDefinedColorName is nil, so colorNameToUse is set to the default of "red"

print(colorNameToUse)

userDefinedColorName = "blue"

colorNameToUse = userDefinedColorName ?? getDefaultColorName()
print(colorNameToUse)

// getDefaultColorName function was called.
// red
// blue