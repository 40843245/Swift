# NOTICE
> [!NOTE]
> `<` and `>` can not be applied to two Bool and so for `<=` and `>=` for two Bool.

> [!NOTE]
> The Swift standard library includes tuple comparison operators for tuples with fewer than seven elements. 
> 
> To compare tuples with seven or more elements, you must implement the comparison operators yourself.