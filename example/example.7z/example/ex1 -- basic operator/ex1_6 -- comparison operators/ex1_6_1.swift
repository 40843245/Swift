func printComparisonOperationResult(x:Int,y:Int){
    print(x)
    print(y)
    print("\(x) == \(y)?\(x == y)")
    print("\(x) != \(y)?\(x != y)")
    print("\(x) < \(y)?\(x < y)")
    print("\(x) > \(y)?\(x > y)")
    print("\(x) <= \(y)?\(x <= y)")
    print("\(x) >= \(y)?\(x >= y)")
}

let integer1 = 3
let integer2 = 4
let integer3 = 3
let tuple1 = (1, "zebra")
let tuple2 = (2, "apple")
let tuple3 = (3, "apple")
let tuple4 = (3, "bird") 
let tuple5 = (5, "dog")
let tuple6 = ("blue", -1)
let tuple7 = ("purple", 1)
let tuple8 = ("blue", false)
let tuple9 = ("purple", true) 

printComparisonOperationResult(integer1,integer1)

printComparisonOperationResult(integer1,integer2)

printComparisonOperationResult(integer1,integer3)

printComparisonOperationResult(integer2,integer2)

printComparisonOperationResult(integer2,integer3)

printComparisonOperationResult(integer3,integer3)

printComparisonOperationResult(tuple1,tuple2)

printComparisonOperationResult(tuple3,tuple4)

printComparisonOperationResult(tuple5,tuple5)

printComparisonOperationResult(tuple6,tuple7)

printComparisonOperationResult(tuple8,tuple9) // When comparing tuple8 < tuple9, tuple8 > tuple9, 
// it will throw runtime Error since `<` and `>` can not applied to Bool. 
// Similarly for `tuple8 <= tuple9` and `tuple8 >= tuple9`.
