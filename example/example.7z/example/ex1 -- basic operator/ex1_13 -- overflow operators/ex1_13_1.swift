func printOverflowOperatorResult(x:Int,y:Int){
    print(x)
    print(y)
    print("\(x) &+ \(y):\(x &+ y)")
    print("\(x) &- \(y):\(x &- y)")
    print("\(x) &* \(y):\(x &* y)")
    print("\(x) &/ \(y):\(x &/ y)")
}

let integer1 = Int.max
let integer2 = Int.min
let integer3 = 1

printOverflowOperatorResult(integer1,integer2)
printOverflowOperatorResult(integer1,integer3)