/// example of use of ternary conditional operator.
/// `? expression :` behaves same that in C. 
let contentHeight = 40
let hasHeader = true
var rowHeight = contentHeight + (hasHeader ? 50 : 20) // rowHeight is equal to 90
// is equivalent to 
rowHeight = contentHeight + if(hasHeader){ 50 } else { 20 }

// is also equivalent to
if hasHeader {
    rowHeight = contentHeight + 50
} else {
    rowHeight = contentHeight + 20
}