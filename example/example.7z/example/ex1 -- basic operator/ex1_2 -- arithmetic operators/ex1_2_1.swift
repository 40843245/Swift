let integer1 = 1 + 2       // equals 3
let integer2 = 5 - 3       // equals 2
let integer3 = 2 * 3       // equals 6
let double1 = 10.0 / 2.5  // equals 4.0
let integer4 = 9 % 4    // equals 1 since `9` = (`4` x `2`) + `1`
let integer5 = -9 % 4   // equals -1 since `-9` = (`4` x `-2`) + `-1`