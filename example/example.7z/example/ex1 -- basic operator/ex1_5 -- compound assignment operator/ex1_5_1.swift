var a = 1
a += 2 // is equivalent to `a = a + 2`
a -= 3 // is equivalent to `a = a - 3`
a *= 4 // is equivalent to `a = a * 4`
a /= 4 // is equivalent to `a = a / 4`