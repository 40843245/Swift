# NOTICE
> [!NOTE]
> The compound assignment operators don’t return a value. 
For example, you can’t write `let b = a += 2` (which is NOT equivalent to `let b = a = a + 2`).