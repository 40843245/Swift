let b = 10
var a = 5
a = b
// a is now equal to 10

let (x, y) = (1, 2)
// x is equal to 1, and y is equal to 2

if x = y {
    // This isn't valid, because x = y doesn't return a value.
}