func printBitwiseOperationResult(x:Int,y:Int){
    print(x)
    print(y)
    print("~\(x):\(~x)")
    print("\(x) & \(y):\(x & y)")
    print("\(x) | \(y):\(x | y)")
    print("\(x) ^ \(y):\(x ^ y)")
    print("\(x) << \(y):\(x << y)")
    print("\(x) >> \(y):\(x >> y)")
}

let integer1 = 31
let integer2 = 63

printBitwiseOperationResult(integer1,integer2)