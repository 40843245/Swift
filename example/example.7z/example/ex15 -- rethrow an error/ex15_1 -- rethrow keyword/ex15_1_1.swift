func someFunction(callback: () throws -> Void) rethrows {
    try callback()
}