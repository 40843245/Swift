func someFunction<E: Error>(callback: () throws(E) -> Void) throws(E) {
    try callback()
}