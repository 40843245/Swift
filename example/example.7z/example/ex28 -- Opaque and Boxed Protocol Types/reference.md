# reference
## guide reference
See [`Opaque and Boxed Protocol Types` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/opaquetypes)