let integer1: Int = 2
let integer2: Int32 = Int32(integer1)