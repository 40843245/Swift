let pi = 3.14159
let integerPi = Int(pi)
// integerPi equals result after truncating pi which equals to 3, and is inferred to be of type Int