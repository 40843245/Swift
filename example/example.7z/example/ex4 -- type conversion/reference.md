# reference
## guide reference
See [`Basic of Swift#Numeric Type Conversion` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics#Numeric-Type-Conversion)