# reference
## guide reference
See [`Regular Expression Literals`](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/lexicalstructure#Regular-Expression-Literals)