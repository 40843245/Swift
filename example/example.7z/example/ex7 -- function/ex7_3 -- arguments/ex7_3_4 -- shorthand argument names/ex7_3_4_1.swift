/*
    See ex7_9_1_4.swift.
*/
let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

// Shorthand Argument Names
var reversedNames = names.sorted(by: { $0 > $1 } )
// reversedNames is equal to ["Ewa", "Daniella", "Chris", "Barry", "Alex"]