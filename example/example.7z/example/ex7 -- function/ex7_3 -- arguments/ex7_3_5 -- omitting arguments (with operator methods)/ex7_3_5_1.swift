/*
    + See ex7_3_4_1.swift.
    + See ex7_9_1_4.swift.
*/

func backward(_ s1: String, _ s2: String) -> Bool {
    return s1 > s2
}
let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

// Shorthand Argument Names
var reversedNames = names.sorted(by: { > } )
// reversedNames is equal to ["Ewa", "Daniella", "Chris", "Barry", "Alex"]