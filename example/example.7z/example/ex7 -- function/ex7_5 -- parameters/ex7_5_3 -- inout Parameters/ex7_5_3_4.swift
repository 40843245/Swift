func someFunction(a: inout Int) -> () -> Int {
    return { [a] in return a + 1 }
}