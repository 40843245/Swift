# analogous 
Analogous to C. 

You can think defining a function with an in-out parameter in Swift is analogous to defining a function with a pointer parameter (parameter that is passed as reference) in C.

You can think passing an argument with prefix `&` symbol when invoking a function in Swift is analogous to pass by a reference for that argument when invoking a function in C.

# NOTICE
> [!NOTE]
> 1. In-out parameters can’t have default values
> 
> 2. variadic parameters can’t be marked as `inout`.
> 
> 3. In-out parameters aren’t the same as returning a value from a function. 
> 
> The `swapTwoInts` example above doesn’t define a return type or return a value, 
> 
> but it still modifies the values of `someInt` and `anotherInt`. 
>
> In-out parameters are an alternative way for a function to have an effect outside of the scope of its function body.