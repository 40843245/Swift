let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

// Inferring Type From Context
var reversedNames = names.sorted(by: { s1, s2 in return s1 > s2 } )
// reversedNames is equal to ["Ewa", "Daniella", "Chris", "Barry", "Alex"]