let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

// Implicit Returns from Single-Expression Closures
var reversedNames = names.sorted(by: { s1, s2 in s1 > s2 } )
// reversedNames is equal to ["Ewa", "Daniella", "Chris", "Barry", "Alex"]