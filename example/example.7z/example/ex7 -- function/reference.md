# reference
## guide reference
See [`Functions` (official website)](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/functions)