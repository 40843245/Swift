let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

// calling function with trailing closure.
var reversedNames = names.sorted{ $0 > $1 }
// reversedNames is equal to ["Ewa", "Daniella", "Chris", "Barry", "Alex"]