# NOTICE
> [!NOTE]
> The underlying type of an optional value is `Optional`, 
> 
> which is an enumeration in the Swift standard library.
> However, optionals are an exception to the rule that value types can’t be marked with `unowned`.
> 
> The optional that wraps the class doesn’t use reference counting,
> 
> so you don’t need to maintain a strong reference to the optional.