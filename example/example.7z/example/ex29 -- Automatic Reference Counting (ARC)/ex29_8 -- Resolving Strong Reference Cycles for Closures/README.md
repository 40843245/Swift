# NOTICE
> [!NOTE]
> Swift requires you to write `self.someProperty` or `self.someMethod()` 
> 
> (rather than just `someProperty` or `someMethod()`) 
> 
> whenever you refer to a member of `self` within a closure. 
> 
> This helps you remember that it’s possible to capture `self` by accident.

> [!TIP]
> If a closure list can be inferred from the context, then the parameter list and return type can be omited.
> 
> To learn more, compare the difference between `ex29_8_1.swift` and `ex29_8_2.swift`.

> [!NOTE]
> If the captured reference will never become `nil`, 
> 
> it should always be captured as an unowned reference, rather than a weak reference.