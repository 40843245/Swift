class Person {
    let name: String
    init(name: String) { self.name = name }
    var apartment: Apartment?
    deinit { print("\(name) is being deinitialized") }
}

class Apartment {
    let unit: String
    init(unit: String) { self.unit = unit }
    weak var tenant: Person?
    deinit { print("Apartment \(unit) is being deinitialized") }
}

var john: Person?
var unit4A: Apartment?

john = Person(name: "John Appleseed")
unit4A = Apartment(unit: "4A")

/// structure in ex29_4_1_figure1.png
john!.apartment = unit4A
unit4A!.tenant = john

/// structure in ex29_4_1_figure2.png
john = nil
// Prints "John Appleseed is being deinitialized"

/// structure in ex29_4_1_figure3.png
unit4A = nil
// Prints "Apartment 4A is being deinitialized"