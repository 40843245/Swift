# NOTICE
> [!NOTE]
> Property observers aren’t called when ARC sets a weak reference to nil.

> [!NOTE]
> In systems that use garbage collection,
>
> weak pointers are sometimes used to implement a simple caching mechanism
>
> because objects with no strong references are deallocated only when memory pressure triggers garbage collection. 
> 
> However, with ARC, values are deallocated as soon as their last strong reference is removed, 
> 
> making weak references unsuitable for such a purpose.