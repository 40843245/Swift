# IMPORTANT
> [!NOTE]
> Important
> 
> Use an unowned reference only when you are sure that the reference _always_ refers to an instance that hasn’t been deallocated.
> 
> If you try to access the value of an unowned reference after that instance has been deallocated,
> 
> you’ll get a runtime error.

> [!NOTE]
> The `number` property of the `CreditCard` class is defined with a type of `UInt64` rather than `Int`,
>
> to ensure that the `number` property’s capacity is large enough to 
> 
> store a 16-digit card number on both 32-bit and 64-bit systems.

> [!NOTE]
> The examples above show how to use _safe_ unowned references. 
> 
> Swift also provides _unsafe_ unowned references for cases where you need to disable runtime safety checks — for example, for performance reasons. 
> 
> As with all unsafe operations, you take on the responsibility for checking that code for safety.
> 
> You indicate an unsafe unowned reference by writing `unowned(unsafe)`. 
> 
> If you try to access an unsafe unowned reference after the instance that it refers to is deallocated, 
> 
> your program will try to access the memory location where the instance used to be, 
> 
> which is an unsafe operation.